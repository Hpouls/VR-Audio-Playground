# Android Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
import os
from os import path
from BuildWwiseUnityIntegration import MultiArchBuilder
from GenerateApiBinding import GccSwigCommand
from PrepareSwigInput import SwigPlatformHandlerPOSIX, SwigApiHeaderBlobber, PlatformStructProfile

class AndroidBuilder(MultiArchBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		MultiArchBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)
		self.compiler = os.environ[BuildUtil.AndroidNdkEnvVar] + "\\ndk-build.cmd"
		
	def _CreateCommands(self, arch=None, config='Profile'):
		cmds = []

		for t in self.tasks:
			cmds.append(['{}'.format(self.compiler), 'PM5_CONFIG={0}_android_{1}'.format(config.lower(), arch), 'NDK_LIBS_OUT=libs\{}'.format(config),'NDK_OUT=out\{}'.format(config)])
			cmds.append(['xcopy', os.path.join('libs', config, arch ,'libAkSoundEngine.so'), os.path.join('..', '..', 'Integration', 'Assets', 'Wwise', 'API', 'Runtime', 'Plugins', 'Android', arch, config, 'stripped_libAkSoundEngine.so*'), '/Y'])
			cmds.append(['xcopy', os.path.join('out', config, 'local', arch ,'libAkSoundEngine.so'), os.path.join('..', '..', 'Integration', 'Assets', 'Wwise', 'API', 'Runtime', 'Plugins', 'Android', arch, config, 'libAkSoundEngine.so*'), '/Y'])
			
		return cmds

	def _RunCommands(self, cmds):
		previous_cwd = os.getcwd()
		os.chdir('../Android')
		isSuccess = MultiArchBuilder._RunCommands(self, cmds)
		os.chdir(previous_cwd)
		return isSuccess

class AndroidSwigCommand(GccSwigCommand):
	def __init__(self, pathMan):
		GccSwigCommand.__init__(self, pathMan)

		self.platformDefines += ['-D__ANDROID__', '-DAK_ANDROID']
		self.dllName = ['-dllimport', self.pathMan.ProductName]

		Arch = 'arch-arm'
		incpath = os.path.join(os.environ['ANDROID_NDK_HOME'], 'toolchains', 'llvm', 'prebuilt', 'windows-x86_64', 'sysroot', 'usr', 'include')
		if not path.lexists(incpath):
			# Fallback on legacy NDK paths
			incpath = os.path.join(os.environ['ANDROID_NDK_HOME'], 'sysroot', 'usr', 'include')
		
		self.Includes = ['-I%s' % incpath]

class SwigApiHeaderBlobberAndroid(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/Android/AkAndroidSoundEngine.h')))

class SwigPlatformHandlerAndroid(SwigPlatformHandlerPOSIX):
	def __init__(self, pathMan):
		SwigPlatformHandlerPOSIX.__init__(self, pathMan)

		self.ioFileSources = \
		[
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/POSIX/stdafx.cpp'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/POSIX/stdafx.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/Android/AkFileHelpers.cpp'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/Android/AkFileHelpers.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/Android/AkFileHelpersAndroid.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/Android/AkDefaultIOHookBlocking.cpp'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/Android/AkDefaultIOHookBlocking.h'),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine/Android/AkFilePackageLowLevelIOBlocking.h')
		]

def Init(argv=None):
	BuildUtil.BankPlatforms['Android'] = 'Android'
	BuildUtil.SupportedArches['Android'] = ['armeabi-v7a', 'arm64-v8a', 'x86']
	BuildUtil.PremakeParameters['Android'] = { 'os': 'android', 'generator': 'androidmk' }
	BuildUtil.PlatformSwitches['Android'] = '#if UNITY_ANDROID && ! UNITY_EDITOR'
	BuildUtil.SupportedPlatforms['Windows'].append("Android")

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return AndroidBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return AndroidSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerAndroid(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberAndroid(pathMan)

if __name__ == '__main__':
	pass
