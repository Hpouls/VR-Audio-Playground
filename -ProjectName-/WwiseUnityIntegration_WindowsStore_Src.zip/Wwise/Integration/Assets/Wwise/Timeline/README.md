# Unity Wwise Timeline

This package adds support for using Wwise Event and RTPC in the Unity Timeline.

## Usage

See [Unity Wwise Timeline Documentation](https://www.audiokinetic.com/library/edge/?source=Unity&id=unity_timeline.html) for more information about how to use the package.

## Requirements

* Unity.Timeline >= 1.1.0

## Legal

Copyright © 2020 Audiokinetic Inc. All rights reserved.
